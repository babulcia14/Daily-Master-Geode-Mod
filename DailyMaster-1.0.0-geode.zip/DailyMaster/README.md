# Daily Master 1.0.0

Daily Master automatycznie odbiera **już zdobytą nagrodę za Daily Level** w Geometry Dash. Warunek: trzeba wcześniej samodzielnie ukończyć właściwy Daily w zwykłym trybie na 100%. Mod naciska istniejący przycisk odbioru w oknie gry i potwierdza zmianę stanu nagrody.

**Nie trzeba znać C++ ani kompilować programu, aby używać gotowego pliku `aer.daily_master.geode`.** Kompilacja oznacza przetworzenie kodu źródłowego w gotowy mod. To osobna opcja dla osób, które chcą go później zmienić.

## Zacznij tutaj

W archiwum wydania znajdziesz gotowy plik `.geode`, instalator pomocniczy i cały projekt źródłowy. Plik `.geode` jest modem; ZIP służy jedynie do wygodnego przesłania wszystkich plików.

1. Zamknij Geometry Dash normalnym przyciskiem wyjścia, aby gra zapisała postęp.
2. Jeśli korzystasz z ZIP: kliknij go prawym przyciskiem myszy, wybierz **Wyodrębnij wszystkie**, a potem **Wyodrębnij**. Otwórz wypakowany folder `DailyMaster`.
3. Kliknij dwukrotnie **ZAINSTALUJ.cmd**. Skrypt sprawdzi, czy gra jest zamknięta, znajdzie instalację Steam i skopiuje tylko Daily Master. Jeśli istnieje poprzednia wersja tego moda, zachowa jej kopię z rozszerzeniem `.bak`.
4. Gdy zobaczysz komunikat **Zainstalowano Daily Master**, zamknij okno instalatora dowolnym klawiszem.
5. Uruchom grę przez Steam. W dolnym rzędzie menu głównego znajdziesz niebieską skrzynkę ze złotym zamkiem na niebieskim przycisku. Otwiera ona panel Daily Master.

Jeżeli skrypt nie znajdzie gry albo pokaże błąd, nie musisz niczego programować. Skopiuj treść komunikatu i przekaż ją osobie pomagającej przy instalacji. Możesz również użyć metody ręcznej opisanej niżej.

## Wymagania i zgodność

| Element | Wersja docelowa |
| --- | --- |
| System | Windows 11, 64 bity |
| Gra | Geometry Dash **2.2081**, Steam |
| Geode | **5.11.2**, zgodne wydania 5.x |
| Zależność | Node IDs (`geode.node-ids`) 1.23.3 lub zgodne nowsze 1.x |
| Internet | Potrzebny do odświeżenia aktualnego numeru Daily i pobrania poziomu |

Stan sprawdzono 17.10.2026. Zainstalowana gra ma znacznik PE `1768959392`, który oficjalny Geode przypisuje do 2.2081. Geode 5.11.2 jest aktualnym stabilnym wydaniem w momencie przygotowania projektu. Publiczne wydania Geode wspominają już GD 2.209, ale SDK 5.11.2 nadal celuje w 2.2081. **Ta paczka nie deklaruje obsługi 2.209.** Po zmianie głównej wersji SDK lub gry należy zaktualizować kod, zbudować go ponownie i sprawdzić w grze. Nie należy zmieniać numeru GD w `mod.json` tylko po to, aby obejść kontrolę zgodności.

## Co dokładnie robi mod

- Sprawdza numer aktualnego Daily poprzez standardowe, asynchroniczne zapytanie Geometry Dash.
- Pokazuje status aktywnego, pobranego Daily i jego postęp. Aktywny poziom może być starszy niż najnowszy numer z serwera; oba są opisane osobno.
- Po wejściu do menu otwiera normalne okno Daily, jeśli zapis gry zawiera gotową nagrodę i włączono odpowiednie opcje.
- W oknie Daily odnajduje prawdziwy przycisk odbioru i aktywuje go tylko dla prawidłowego Daily ukończonego na 100%.
- Po potwierdzonej przez grę zmianie stanu zapisuje czas ostatniego odbioru i opcjonalnie wyświetla powiadomienie.
- Obsługuje również ręczny odbiór nagrody: zostaje zapisany w `Last Claim`.
- Nie zmienia procentów, statystyk, walut ani wyników. Nie wysyła własnych żądań przyznania nagród.

To **nie jest automat do grania**. Odbiór nagrody odbywa się w zwykłym oknie gry; jej animacja pozostaje widoczna. Jeśli Daily nie został jeszcze pobrany, wybierz **Daily** i pozwól grze go pobrać. Gra nie udostępnia zdobytej nagrody za poziom, którego nie ukończono.

## Panel i ustawienia

Kliknij ikonę niebieskiej skrzynki ze złotym zamkiem w dolnym rzędzie menu głównego.

| Pole / opcja | Znaczenie |
| --- | --- |
| **Auto Claim Daily** | Włącza automatyczne naciśnięcie przycisku odbioru gotowej nagrody. Domyślnie włączone. |
| **Notifications** | Powiadomienie Daily Master po potwierdzonym odbiorze. Nie wyłącza animacji nagrody samej gry. |
| **Check on Startup** | Sprawdzenie przy uruchomieniu i automatyczne otwieranie gotowej nagrody z menu głównego. Gdy wyłączone, można nadal używać przycisku Daily, a automat działa w otwartym oknie Daily. |
| **Daily Status** | Odczyt rzeczywistego statusu aktywnego Daily. To informacja, a nie przełącznik. |
| **Last Claim** | Ostatni odbiór zaobserwowany przez ten mod, osobno dla każdego konta. Data jest w lokalnym czasie Windows. To informacja, a nie pole do edycji. |
| **Debug Logging** | Dodatkowe komunikaty w standardowym logu Geode. Domyślnie wyłączone. |
| **Sprawdź** | Odświeża status z serwera. Minimum 30 sekund między zapytaniami; czas oczekiwania wynosi do 20 sekund. |
| **Daily** | Otwiera normalne okno Daily w grze. |
| **Opcje** | Otwiera standardowe ustawienia Geode dla Daily Master. |

Przełączniki działają od razu i są zapisywane. Status jest obliczany ponownie z aktualnego zapisu gry. Historia odbioru nie zastępuje stanu nagrody w Geometry Dash. Czcionki gry mają ograniczony zestaw znaków, dlatego polskie etykiety wewnątrz gry używają liter bez polskich znaków.

## Ręczna instalacja — tylko jeśli potrzebna

1. Zamknij Geometry Dash.
2. Otwórz Steam i kliknij **Biblioteka**.
3. Kliknij prawym przyciskiem **Geometry Dash** na liście gier.
4. Wybierz **Zarządzaj → Przeglądaj pliki lokalne**.
5. Otworzy się folder z plikiem `GeometryDash.exe`. Otwórz w nim folder **geode**, a następnie **mods**.
6. W drugim oknie Eksploratora znajdź wypakowany `aer.daily_master.geode`. Zaznacz go, naciśnij **Ctrl+C**, przejdź do folderu `mods` i naciśnij **Ctrl+V**.
7. Uruchom grę przez Steam. W Geode sprawdź listę zainstalowanych modów — powinien pojawić się **Daily Master 1.0.0**.

Jeśli brakuje Node IDs, otwórz Geode, wyszukaj **Node IDs**, wybierz instalację i uruchom grę ponownie. W instalacji sprawdzonej podczas tworzenia projektu ta zależność już była obecna.

Nie kopiuj plików `.cpp`, `.hpp`, PNG ani `mod.json` do folderu `mods`. Wszystko potrzebne grze jest już wewnątrz paczki `.geode`.

## Co oznaczają pliki projektu

| Plik / folder | Do czego służy |
| --- | --- |
| `aer.daily_master.geode` | Gotowy mod w archiwum wydania. Tylko ten plik musi trafić do gry. |
| `ZAINSTALUJ.cmd` | Uruchamia pomocniczy skrypt instalacji. |
| `ZBUDUJ.cmd` | Buduje moda z kodu; wymaga narzędzi opisanych poniżej. |
| `src/` | Cały kod C++. Nie musisz go edytować. |
| `mod.json` | Nazwa, ID, autor, wersje, ustawienia i zasoby. Autor jest w polu `developer`. |
| `CMakeLists.txt` | Instrukcja budowania dla CMake. |
| `logo.png` | Ikona 512 × 512 wyświetlana przez Geode. |
| `resources/daily-master.png` | Grafika przycisku; Geode tworzy warianty dla jakości tekstur. |
| `artwork/` | Przesłane obrazy, źródło SVG, skrypt składania, PNG 512 i 256 oraz próba czytelności; bez generowania AI. |
| `tests/` | Testy zasad dopuszczania odbioru nagrody. |
| `docs/RESEARCH.md` | Źródła, prawdziwe API i wnioski z analizy. |
| `docs/TEST_REPORT.md` | Wyniki wykonanych testów oraz lista prób wymagających gry. |

## Budowanie na tym komputerze

Zestaw narzędzi został przygotowany obok projektu, w folderze `.tools`. Zachowaj oba foldery w tym samym położeniu. W folderze `DailyMaster` kliknij **ZBUDUJ.cmd**. Poczekaj na zielony komunikat o gotowym modzie. Plik wynikowy znajdziesz w `DailyMaster/build/aer.daily_master.geode`.

Folder `.tools` nie jest dołączony do ZIP, ponieważ zawiera duże zewnętrzne narzędzia i biblioteki. Wypakowanie samego ZIP na innym komputerze pozwala zainstalować gotowego moda, ale do ponownej kompilacji trzeba przygotować narzędzia.

## Budowanie na nowym Windows 11

Poniższe etapy są instrukcją do wykorzystania później. **Do instalacji gotowej paczki nie wykonuj żadnego z nich.**

### 1. Narzędzia Microsoft C++

Otwórz [oficjalną stronę Microsoft](https://visualstudio.microsoft.com/downloads/). W części narzędzi znajdź **Build Tools for Visual Studio**. Pobierz i uruchom instalator. Zaznacz **Programowanie aplikacji klasycznych w języku C++** (ang. **Desktop development with C++**), pozostaw MSVC i Windows SDK, a następnie kliknij **Zainstaluj**. Wymagane jest Visual Studio 2022 lub nowsze. Pełny edytor Visual Studio nie jest konieczny.

### 2. CMake, Git, Ninja i Geode CLI

Kliknij prawym przyciskiem przycisk Start Windows i wybierz **Terminal**. Wklej poniższe polecenia po jednym, za każdym naciskając Enter i czekając na zakończenie. Są to polecenia instalacji narzędzi przez systemowy menedżer pakietów Windows:

```powershell
winget install --id Kitware.CMake -e
winget install --id Git.Git -e
winget install --id Ninja-build.Ninja -e
winget install --id GeodeSDK.GeodeCLI -e
```

CMake musi mieć wersję co najmniej 3.29. Zamknij terminal po instalacji, aby następne okno zobaczyło nowe programy.

### 3. Geode SDK 5.11.2

W menu Start wyszukaj **x64 Native Tools Command Prompt for VS 2022** i otwórz ten program. Jeśli używasz innego wydania Visual Studio, wybierz jego odpowiednik dla x64. Wpisz kolejno:

```text
geode sdk install
geode sdk update v5.11.2
geode sdk install-binaries
geode config setup
```

SDK to pliki programistyczne Geode. Ostatnie polecenie pyta o folder gry: wskaż folder zawierający `GeometryDash.exe`. Nie wskazuj folderu `mods`. Po konfiguracji zamknij i otwórz ponownie okno narzędzi x64. Szczegóły oficjalne: [instalacja SDK](https://docs.geode-sdk.org/getting-started/sdk/) i [Geode CLI](https://docs.geode-sdk.org/getting-started/geode-cli/).

### 4. Otwórz folder projektu w terminalu

Otwórz `DailyMaster` w Eksploratorze. Kliknij pasek adresu u góry i skopiuj pełną ścieżkę przez Ctrl+C. W oknie narzędzi x64 wpisz `cd /d `, następnie wklej ścieżkę w cudzysłowie. Przykład:

```text
cd /d "C:\Users\TwojaNazwa\Downloads\DailyMaster"
```

### 5. Konfiguracja i kompilacja

W tym samym oknie wpisz:

```text
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\Build.ps1
```

Skrypt uruchamia CMake, kompilator i standardowe pakowanie Geode. Nie instaluje automatycznie wyniku w grze. Pierwsze budowanie trwa dłużej, ponieważ pobiera zależności. Oczekiwany wynik to komunikat `Gotowy mod:` z pełną ścieżką do pliku.

Równoważne polecenia dla osoby znającej terminal:

```text
cmake -S . -B build -G Ninja -DCMAKE_CXX_COMPILER=cl -DCMAKE_C_COMPILER=cl -DCMAKE_BUILD_TYPE=RelWithDebInfo
cmake --build build --parallel 3
```

SDK obsługuje również zalecany przez Geode `clang-cl`. Przygotowany skrypt wybiera go, jeśli jest dostępny, a w przeciwnym razie używa MSVC. Na komputerze autora tej paczki faktycznie sprawdzono MSVC.

### 6. Testy bez gry

W tym samym oknie możesz uruchomić:

```text
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\Build.ps1 -TestsOnly
```

Wynik powinien zawierać `100% tests passed`. To testy reguł odbioru — nie zastępują uruchomienia moda w Geometry Dash.

## Testowanie w grze

Po instalacji zacznij od otwarcia panelu i wyłączenia **Auto Claim Daily**. Sprawdź etykiety i przycisk **Daily**. Dalsze przypadki opisuje `docs/TEST_REPORT.md`. Do sprawdzenia realnego odbioru potrzebny jest prawdziwie ukończony Daily z nieodebraną nagrodą. Nie zmieniaj zapisu gry, aby sztucznie przygotować ten stan.

## Ograniczenia

- Daily Level wymaga ukończenia konkretnej wersji Daily. Ukończenie tego samego poziomu znalezionego zwykłą wyszukiwarką albo w Practice nie musi zaliczać Daily.
- Małe i duże codzienne skrzynki są oddzielnym mechanizmem. Wersja 1.0.0 ich nie otwiera.
- Weekly Demons i Event Levels pozostają poza automatyzacją wersji 1.0.0.
- Mod ufa zapisowi gry tak samo jak jej przycisk odbioru; nie jest narzędziem sprawdzającym uczciwość zapisów zmienionych przez inne mody.
- Przy braku internetu nadal można odczytać aktywny Daily z zapisu. Nie można wtedy potwierdzić najnowszego numeru na serwerze.
- Przy zajętym oknie Daily mod nie przejmuje jego delegata sieciowego. Można spróbować ponownie później.
- Nie skanuje i nie odbiera całego archiwum Daily. Operuje na aktywnym poziomie, który prezentuje standardowe okno gry.
- Godzina `Last Claim` oznacza odbiór zaobserwowany po instalacji moda. Nie odtwarza historii wcześniejszych nagród.
- Inne mody mogą zmienić układ menu albo przycisk odbioru. Jeśli oryginalnego przycisku nie ma, automat nie wykonuje zastępczej operacji przyznania nagrody.

## Najczęstsze problemy

**„Gra jest uruchomiona” w instalatorze:** zamknij ją normalnie, poczekaj kilka sekund i ponownie kliknij `ZAINSTALUJ.cmd`.

**Mod nie jest widoczny:** upewnij się, że skopiowano plik `.geode`, a nie ZIP. Uruchom grę ponownie i sprawdź zakładkę błędów Geode.

**Brak ikony:** sprawdź, czy Daily Master i Node IDs są włączone. Przy zmodyfikowanym menu spróbuj wyłączyć mod zmieniający menu i uruchomić grę ponownie.

**Nagroda się nie odbiera:** sprawdź `Daily Status`, włącz automat i otwórz przycisk `Daily`. Jeśli widzisz mniej niż 100%, gra nie udostępnia jeszcze tej nagrody.

**Błąd zgodności z 2.209 lub nowszym GD:** ta paczka wymaga 2.2081; potrzebna jest aktualizacja moda pod nowe SDK. Nie wyłączaj kontroli zgodności.

**Błąd kompilacji:** skopiuj ostatnie 20–30 wierszy okna. Nie próbuj poprawiać losowych fragmentów kodu ani usuwać zapisów gry.

## Usuwanie

W Geode znajdź Daily Master i wybierz wyłączenie lub odinstalowanie, po czym uruchom grę ponownie. Możesz też zamknąć grę i usunąć wyłącznie `aer.daily_master.geode` z folderu `geode/mods`. Już odebrane legalne nagrody pozostają w zapisie gry.

## Historia zmian

### 1.0.0 — 17.10.2026

- Pierwsze wydanie projektu dla Windows i Geode 5.11.2.
- Automatyczny odbiór zdobytych nagród Daily przez istniejący przycisk gry.
- Panel, cztery zapisywane przełączniki, status i historia ostatniego odbioru.
- Obsługa błędów sieci, limit częstotliwości zapytań i zabezpieczenia przed ponownym odbiorem.
- Oryginalne logo PNG, polska dokumentacja, instalator pomocniczy i testy zasad odbioru.

Kod jest udostępniony na licencji MIT. Nazwę autora zmienia się w polu `developer` pliku `mod.json` i w informacji copyright pliku `LICENSE`; nie trzeba zmieniać kodu C++.
