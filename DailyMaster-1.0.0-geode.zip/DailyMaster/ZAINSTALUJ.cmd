@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Install.ps1"
if errorlevel 1 echo Instalacja nie powiodla sie. Skopiuj komunikat bledu powyzej.
pause
