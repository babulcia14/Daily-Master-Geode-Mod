@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Build.ps1"
if errorlevel 1 echo Budowanie nie powiodlo sie. Skopiuj komunikat bledu powyzej.
pause
