# Daily Master

Automatycznie odbiera zdobyta nagrode za **Daily Level**. Wymagane jest 100% w zwyklym trybie Daily i nieodebrana nagroda.

Zielona ikona kalendarza w dolnym menu otwiera panel. **Daily** otwiera oryginalne okno gry. **Sprawdz** odswieza numer Daily z serwera.

Opcje: Auto Claim Daily, Notifications, Check on Startup, Debug Logging. Panel pokazuje Daily Status i Last Claim.

Mod uzywa oryginalnego przycisku odbioru, nie zmienia procentow i nie tworzy nagrod. Wersja 1.0.0 nie obsluguje codziennych skrzynek, Weekly ani Event.

Windows x64, Geometry Dash 2.2081, Geode 5.11.2, Node IDs 1.23.3+.
