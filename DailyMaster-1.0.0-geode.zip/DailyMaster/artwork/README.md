# Logo Daily Master — złożone bez AI

Niebieska skrzynka ze złotym zamkiem na niebieskim przycisku. Źródłem są dwa obrazy przesłane przez użytkownika. Skrzynkę zachowano, ramkę odtworzono geometrycznie dla ostrych krawędzi. Nie używano generatora AI.

| Plik | Zastosowanie |
| --- | --- |
| `source/LargeChest.png` | Niezmieniony obraz użytkownika, 481 × 385 RGBA. |
| `source/button-reference.png` | Niezmieniona referencja przycisku, 80 × 80 RGBA. |
| `logo-source.svg` | Edytowalna ramka wektorowa z osadzoną rastrową skrzynką PNG. |
| `compose_logo.py` | Odtwarzalny skład i eksport za pomocą Pillow; bez sieci i AI. |
| `logo-original.png`, `logo-512.png` | Kompozycja 512 × 512, identyczna z `../logo.png`. |
| `logo-256.png` | Kompozycja 256 × 256, identyczna z teksturą w `../resources/`. |
| `readability.png` | Arkusz miniatur 24/32/35/48/64/96 px na dwóch tłach; podgląd poza grą. |

Skrzynka w eksporcie 512 ma szerokość 422 px i nie jest powiększana ponad źródło. PNG używają alfa i filtrowania Lanczos. Szczegóły w `../docs/LOGO_COMPOSITION.md`. Zasoby są już podmienione; użytkownik nie musi kopiować tekstur ręcznie.
