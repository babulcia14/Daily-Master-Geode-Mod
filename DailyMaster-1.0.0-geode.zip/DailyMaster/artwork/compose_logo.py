"""Deterministic composition of supplied artwork. Requires Pillow; no AI calls."""
from pathlib import Path
from base64 import b64encode
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
# Coordinates follow the supplied 80px button. Rebuild its simple frame sharply.
RECTS = [
    (0.5, 0.5, 79.5, 79.5, 11, '#ffffff'),
    (2, 2, 78, 78, 10, '#080b10'),
    (5, 5, 75, 75, 7, '#4dc4fe'),
    (6, 8, 74, 75, 6, '#163264'),
    (8, 8, 72, 71, 4, '#2d6ede'),
]
CHEST_BOX = (7, 14, 66, 52.8274428274)

def render(size):
    # Supersample only geometric frame; chest always resamples from supplied PNG.
    scale = size * 4 / 80
    frame = Image.new('RGBA', (size * 4, size * 4))
    draw = ImageDraw.Draw(frame)
    for x1, y1, x2, y2, radius, color in RECTS:
        draw.rounded_rectangle(tuple(v * scale for v in (x1, y1, x2, y2)), radius * scale, fill=color)
    frame = frame.resize((size, size), Image.Resampling.LANCZOS)
    chest = Image.open(ROOT / 'source/LargeChest.png').convert('RGBA')
    x, y, w, h = CHEST_BOX
    chest = chest.resize((round(w * size / 80), round(h * size / 80)), Image.Resampling.LANCZOS)
    frame.alpha_composite(chest, (round(x * size / 80), round(y * size / 80)))
    return frame

def main():
    for size in (512, 256):
        im = render(size)
        im.save(ROOT / f'logo-{size}.png', optimize=True)
        im.save(ROOT.parent / ('logo.png' if size == 512 else 'resources/daily-master.png'), optimize=True)
    render(512).save(ROOT / 'logo-original.png', optimize=True)
    # Editable vector frame plus embedded original raster chest: not a fake all-vector image.
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="512" height="512" viewBox="0 0 80 80">',
             '<title>Daily Master — supplied chest on blue button; no AI generation</title>']
    for x1, y1, x2, y2, radius, color in RECTS:
        parts.append(f'<rect x="{x1}" y="{y1}" width="{x2-x1}" height="{y2-y1}" rx="{radius}" fill="{color}"/>')
    data = b64encode((ROOT / 'source/LargeChest.png').read_bytes()).decode('ascii')
    x, y, w, h = CHEST_BOX
    parts.append(f'<image x="{x}" y="{y}" width="{w}" height="{h}" xlink:href="data:image/png;base64,{data}"/>')
    parts.append('</svg>')
    (ROOT / 'logo-source.svg').write_text('\n'.join(parts), encoding='utf-8')
    sheet = Image.new('RGB', (720, 300))
    d = ImageDraw.Draw(sheet)
    font = ImageFont.load_default(size=14)
    for row, bg in enumerate(('#29324a', '#edf1f3')):
        d.rectangle((0, row*150, 720, (row+1)*150), fill=bg)
        for i, size in enumerate((24, 32, 35, 48, 64, 96)):
            im = render(size)
            sheet.paste(im, (i*120+(120-size)//2, row*150+(116-size)//2), im)
            d.text((i*120+43, row*150+125), f'{size}px', fill='white' if row == 0 else '#202630', font=font)
    sheet.save(ROOT / 'readability.png')
    print('Created composed PNG 512/256, editable SVG, and readability sheet. No AI used.')

if __name__ == '__main__':
    main()
