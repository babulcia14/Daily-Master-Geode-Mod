# 1.0.0

- Automatyczny odbior zdobytych nagrod Daily przez przycisk gry.
- Zapisywane ustawienia i panel statusu.
- Historia ostatniego odbioru na konto.
- Obsluga braku sieci i ochrona przed ponownym odbiorem.
- Oryginalne logo, polska instrukcja i testy.
- Korekta grafiki 18.10.2026: zielona skrzynka z gwiazda i blyskawica; nowe logo i tekstury przycisku, bez zmian funkcji moda.

- Kolejna korekta logo: polaczenie skrzynki i niebieskiego przycisku dostarczonych przez uzytkownika. Bez generowania AI, bez zmian kodu moda.
