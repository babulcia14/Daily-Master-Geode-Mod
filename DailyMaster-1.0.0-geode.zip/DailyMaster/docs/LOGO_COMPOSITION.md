# Aktualne logo — kompozycja bez AI

Poprzedni znak zastąpiono kompozycją dwóch obrazów użytkownika. Do tej zmiany nie używano generatora AI.

Skrzynkę LargeChest.png pomniejszono proporcjonalnie i wyśrodkowano. Ramkę niebieskiego przycisku odtworzono z prostych kształtów na podstawie referencji 80 × 80, aby uzyskać ostre krawędzie w większym rozmiarze. Nie dodano napisów ani nowych symboli. Zewnętrzne narożniki są przezroczyste; niebieskie pole pozostaje nieprzezroczyste.

Źródła użytkownika zachowano bez zmian w `artwork/source/`. Plik `artwork/logo-source.svg` zawiera edytowalną wektorową ramkę i osadzoną oryginalną skrzynkę PNG. Skrzynka nadal jest rastrowa. Skrypt `artwork/compose_logo.py` odtwarza kompozycję z użyciem Pillow, bez sieci i AI.

PNG 512 i 256 są przygotowane do projektu. Skrzynka w wersji 512 ma szerokość 422 px, więc nie powiększono jej ponad źródło 481 px. CLI Geode tworzy tekstury 256/128/64. Konfiguracja i kod moda pozostają bez zmian.

Obejrzano logo 256 px i arkusz miniatur 24/32/35/48/64/96 px na jasnym i ciemnym tle. Przy 32–35 px rozpoznawalna jest skrzynka i złoty zamek; przy 24 px drobne okucia tracą szczegóły. To kontrola poza grą. Instalację i test w Geometry Dash nadal odłożono zgodnie z decyzją użytkownika.

Poprzedni prompt AI usunięto z aktualnego katalogu grafiki. Dokument LOGO_REDESIGN.md jest historycznym opisem odrzuconej wersji.
