> ARCHIWUM: opis poprzedniej, odrzuconej wersji. Aktualna grafika to kompozycja obrazów użytkownika bez AI; zobacz [LOGO_COMPOSITION.md](LOGO_COMPOSITION.md). Wymiary i nazwy źródeł opisane poniżej dotyczą poprzedniego wydania.

# Poprawa logo Daily Master — 18.10.2026

## Referencje i własne obserwacje

Obejrzano rzeczywiste pliki ikon wskazanych modów, a także przesłaną przez użytkownika małą ikonę AUTO CLAIM. Poniższe uwagi są analizą wizualną, nie oficjalnymi zasadami Geode. Ikony różnią się stylistyką; nie wszystkie mają gruby czarny kontur.

| Projekt i źródło | Co widać i co pomaga w małym rozmiarze |
| --- | --- |
| [BetterEdit](https://github.com/HJfod/BetterEdit/blob/v6/logo.png) | Zielony znak B połączony z narzędziami; mocna sylwetka, czarny kontur i jasna zewnętrzna obwódka. Oglądany plik ma 174 × 174 px. |
| [Globed](https://github.com/GlobedGD/globed2/blob/main/logo.png) | Jeden biały glob na szarym polu, wyraźne obramowanie i kontrast. Oglądany plik: 336 × 336 px. |
| [Eclipse](https://geode-sdk.org/mods/eclipse.eclipse-menu?version=1.9.4) | Dwa jasne okręgi na granatowym tle, cienkie linie i światło. Przejrzano logo z lokalnej paczki, 520 × 520 px. Prosta geometria, ale inny styl niż wybrany dla Daily Master. |
| [Prism Menu](https://github.com/FireMario211/Prism-Menu/blob/main/logo.png) | Jasny romb, ciemne pole i fioletowa ramka. Jeden dominujący symbol. Oglądany plik: 336 × 336 px. |
| [Mega Hack — strona autora](https://absolllute.com/store/mega-hack), [plik logo](https://absolllute.com/res/mh.png) | Kanciasty biało-różowy monogram, szerokie kształty i przezroczyste tło. Oglądany plik: 336 × 336 px. |
| [BetterInfo](https://geode-sdk.org/mods/cvolton.betterinfo) | Prosty znak informacji z plusem, kontrastowa fioletowa ramka. Przejrzano logo z lokalnej paczki, 336 × 336 px. |

Wniosek projektowy: ograniczyć liczbę symboli, zachować mocną sylwetkę i duże pola koloru. W Daily Master zastosowano skrzynkę z gwiazdą oraz małą błyskawicę. Nie kopiowano cudzych znaków, napisów ani fragmentów obrazów. Cudze grafiki służyły wyłącznie do porównania i nie są częścią wydania.

Niektóre bezpośrednie strony katalogu Geode i dokumentacji zwracały HTTP 403. Research uzupełniono oficjalnymi repozytoriami GitHub, stroną autora Mega Hack i lokalnymi plikami paczek; nie przedstawiano niedostępnych stron jako obejrzanych obrazów.

## Wymagania techniczne Geode

- [Oficjalna instrukcja tworzenia moda](https://github.com/geode-sdk/docs/blob/main/getting-started/create-mod.md) wskazuje `logo.png` jako ikonę wyświetlaną przez Geode.
- [Kod pakowania CLI v3.9.0](https://github.com/geode-sdk/cli/blob/v3.9.0/src/package.rs) kopiuje `logo.png` z głównego katalogu projektu do głównego katalogu paczki. W sprawdzonej ścieżce pakowania nie narzuca wymiaru w pikselach. 512 × 512 to wybór tego projektu, a nie rzekomo obowiązkowy rozmiar wszystkich ikon Geode.
- [Oficjalna dokumentacja zasobów](https://github.com/geode-sdk/docs/blob/main/mods/resources.md) opisuje PNG w `resources.sprites` oraz automatyczne tworzenie niższych jakości ze źródła UHD. W tym projekcie źródło ma 256 × 256 i CLI tworzy wersje 256/128/64 px.
- Użyto PNG RGBA z rzeczywistą przezroczystością. JPEG nie przechowuje kanału alfa, a SVG nie jest tutaj zasobem ładowanym przez grę. Nie zmieniano istniejącej deklaracji `resources/daily-master.png` w `mod.json` ani nazwy zasobu używanej przez C++.

## Dostarczone pliki

Oryginał `artwork/logo-original.png`: 1254 × 1254 PNG RGBA, wygenerowany wbudowanym imagegen na podstawie własnego opisu. To źródłowy plik rastrowy; nie udaje edytowalnego wektora. Dokładny prompt i rola referencji są zapisane w `artwork/PROMPT.txt`.

`logo.png` i `artwork/logo-512.png`: 512 × 512. `resources/daily-master.png` i `artwork/logo-256.png`: 256 × 256. Wszystkie wersje są pomniejszeniami oryginału z zachowaniem proporcji i alfa. Nie powiększano małego obrazka referencyjnego.

## Kontrola czytelności poza grą

Arkusz `artwork/readability.png` pokazuje rzeczywiste rozmiary 24/32/35/48/64/128 px na jasnym i ciemnym tle. Przy wyświetlaniu arkusza 1:1 próbki nie są powiększone. 35 px odpowiada szerokości przycisku przyjętej w kodzie, lecz rzeczywisty rozmiar ekranowy zależy od skalowania gry.

Przy 32–35 px skrzynka i żółta gwiazda pozostają rozpoznawalne. Przy 24 px mała błyskawica jest już drobnym białym akcentem; tej wielkości nie traktujemy jako zalecanego rozmiaru prezentacji szczegółów. Przy 48–128 px wszystkie trzy elementy są wyraźniejsze. To ocena wizualna na arkuszu, nie test na każdym monitorze ani dowód wyglądu w działającej grze.

Wyniki pakowania i kontroli zgodności plików są dopisane do `TEST_REPORT.md`. Instalację i test w Geometry Dash odłożono zgodnie z decyzją użytkownika.
