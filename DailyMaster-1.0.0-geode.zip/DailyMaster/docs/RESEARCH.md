# Research techniczny — 17.10.2026

Research wykonano przed implementacją. Wykorzystano oficjalne dokumenty, repozytoria Geode, dostępne pliki SDK i odczyt lokalnego pliku wykonywalnego gry. Nie modyfikowano pliku gry ani zapisów.

## Wersje i rzeczywiste środowisko

- [Geode 5.11.2 — wydanie oficjalne](https://github.com/geode-sdk/geode/releases/tag/v5.11.2), commit `3909856e8714b503945d5cea12ba1bddf5d5b1b0`.
- [CMake SDK 5.11.2](https://github.com/geode-sdk/geode/blob/v5.11.2/CMakeLists.txt) określa docelowy GD jako 2.2081. Wydanie zawiera poprawki dotyczące 2.209, ale nie zapewnia pełnych bindings 2.209 dla tego moda.
- [Oficjalne ogłoszenia gry na Steam](https://store.steampowered.com/news/app/322170) i informacja o wydaniu Geode wskazują nowszy cykl aktualizacji 2.209. Nie utożsamiono najnowszej wersji gry z wersją obsługiwaną przez stabilne SDK.
- Lokalny `GeometryDash.exe`: PE timestamp `0x69702da0` = `1768959392`. [Mapa wersji Geode](https://github.com/geode-sdk/geode/blob/v5.11.2/loader/src/platform/windows/gdTimestampMap.hpp) przypisuje ten znacznik do **2.2081**. Zgadza się to z logiem zainstalowanego Geode 5.11.2.
- Definicje API przypięto do `1605f500d053f8de122bf5c7dc6d17c24866e02e`, wskazanego w logu Geode. Zawartość `bindings/2.2081` była identyczna z bieżącą rewizją sprawdzoną na początku pracy.
- [Geode CLI 3.9.0](https://github.com/geode-sdk/cli/releases/tag/v3.9.0) służy do standardowego pakowania `.geode`.

## Daily, Weekly i nagroda

Podstawą są [oficjalne bindings GD 2.2081](https://github.com/geode-sdk/bindings/blob/1605f500d053f8de122bf5c7dc6d17c24866e02e/bindings/2.2081/GeometryDash.bro) i [typy SDK](https://github.com/geode-sdk/bindings/blob/1605f500d053f8de122bf5c7dc6d17c24866e02e/bindings/include/Geode/Enums.hpp).

Daily i Weekly są odrębnymi typami poziomów czasowych: `GJTimedLevelType::Daily` i `Weekly`; istnieje także `Event`. Gra utrzymuje osobno ID aktualnego poziomu na serwerze oraz ID aktywnego poziomu gracza. Identyfikator Daily nie jest zwykłym identyfikatorem poziomu. W tej wersji Weekly używa zakresu od 100000, a Event od 200000.

Zweryfikowane funkcje:

| Rzeczywiste API | Użycie w modzie |
| --- | --- |
| `GameLevelManager::getGJDailyLevelState(GJTimedLevelType)` | Standardowe asynchroniczne sprawdzenie numeru Daily. |
| `GJDailyLevelDelegate::dailyStatusFinished / dailyStatusFailed` | Obsługa odpowiedzi i błędu. |
| `GameLevelManager::getActiveDailyID / getDailyID / getSavedDailyLevel` | Odczyt właściwego aktywnego poziomu. |
| `GJGameLevel::getNormalPercent`, `m_dailyID`, `m_levelID`, `m_stars` | Odczyt warunków odbioru bez ich modyfikacji. |
| `GameStatsManager::hasCompletedDailyLevel(int)` | Sprawdzenie, czy nagrodę już odebrano; nazwa może być myląca. |
| `DailyLevelPage::create / show` | Otwarcie oryginalnego okna. |
| `DailyLevelNode::onClaimReward(CCObject*)` | Rozpoznanie rzeczywistego przycisku odbioru po jego odbiorcy i selektorze. |
| `CCMenuItem::activate()` | Uruchomienie standardowej obsługi przycisku z prawidłowym nadawcą. |
| `DailyLevelPage::claimLevelReward` | Obserwacja stanu przed i po oryginalnej operacji gry. |

Lokalna analiza tylko do odczytu potwierdziła, że `GameStatsManager::completedDailyLevel` sprawdza dodatni Daily ID, dodatnie gwiazdki, normalny postęp co najmniej 100 i brak wcześniejszego odbioru. Native `DailyLevelNode::onClaimReward` przekazuje żądanie do strony i następnie wyłącza przekazany przycisk. Wywołanie z `nullptr` jako nadawcą byłoby błędne. Dlatego mod aktywuje prawdziwy przycisk, a nie wywołuje samego handlera z pustym parametrem.

**Wniosek implementacyjny:** można automatyzować odebranie nagrody, którą gra już dopuszcza. Nie można legalnie tworzyć nagrody za nieukończony poziom. Własny kod nie wywołuje bezpośrednio metod dopisujących walutę, nie ustawia procentów i nie wysyła fikcyjnych wyników. Stan jest oparty na zapisie gry, nie na nowej niezależnej walidacji serwera wymyślonej przez mod.

## Sieć i cykl życia

Zapytania o numer Daily wykonuje klient sieciowy gry. Mod nie używa blokujących zapytań HTTP ani własnych adresów API Boomlings. Wykorzystuje pojedynczy delegat gry tylko wtedy, gdy jest wolny. Zwalnia wyłącznie własny wskaźnik; otwarcie normalnego okna Daily może przejąć odpowiedź, a hook jego callbacku aktualizuje status panelu. Limit 30 sekund zapobiega spamowaniu żądaniami. Po 20 sekundach bez odpowiedzi panel informuje o użyciu danych lokalnych. Nie występuje aktywne oczekiwanie w głównym wątku.

Referencje do przycisku i węzła są utrzymywane na czas aktywacji, bo gra może w trakcie usunąć stary węzeł Daily. Wskaźników do zamkniętej strony nie przechowuje się w singletonie. Zapis nagrody następuje tylko po przejściu flagi gry z nieodebranej na odebraną. `Last Claim` jest metadanymi moda, nie blokadą zastępującą zapis gry.

## Interfejs i ustawienia

[Dokumentacja ustawień](https://docs.geode-sdk.org/mods/settings/) i nagłówki SDK 5.11.2 potwierdzają użycie `getSettingValue`, `setSettingValue` oraz zapisywanych wartości `Mod`. Cztery przełączniki mają typ `bool` w `mod.json`; status i data są polami odczytu panelu. Zmiana opcji nie wymaga restartu.

Interfejs korzysta z rzeczywistych komponentów: `geode::Popup` (w Geode 5 bez dawnego szablonu `Popup<>`), `CCScale9Sprite`, `ButtonSprite`, `CCMenuItemToggler`, `CCLabelBMFont`, `Notification` i układu menu przez Node IDs. Tekst ma ograniczaną szerokość. Popup skaluje się do okna, a jego własna krótka animacja zachowuje końcową skalę; standardowa animacja FLAlertLayer przywracałaby skalę 1.

## Ikona i zasoby

Przejrzano rzeczywiste logo **BetterInfo** i **Eclipse**, znajdujące się w zainstalowanych paczkach: pojedynczy czytelny symbol, mocne obramowanie, wysoki kontrast, ograniczona paleta. Informacje o projektach: [BetterInfo](https://geode-sdk.org/mods/cvolton.betterinfo), [Eclipse](https://geode-sdk.org/mods/eclipse.eclipse-menu). Nie skopiowano ich znaków ani grafik do wydania Daily Master.

[Dokumentacja zasobów](https://docs.geode-sdk.org/mods/resources/) opisuje PNG i automatyczne tworzenie wersji jakości tekstur. [Kod CLI](https://github.com/geode-sdk/cli/blob/v3.9.0/src/package.rs) kopiuje `logo.png` z katalogu głównego jako ikonę moda; nie narzuca jednego rozmiaru w pikselach. Dlatego wykorzystano kwadrat **512 × 512 PNG RGBA**, a nie zadeklarowano fikcyjnego obowiązkowego limitu. Dodatkowo dostarczono 256 × 256.

Grafika przycisku ma źródłowo 256 × 256. Geode traktuje ją jako UHD i automatycznie pakuje 256/128/64 px. Kod używa nazw z `_spr`, aby uniknąć konfliktów zasobów z innymi modami. Aktualne logo złożono bez generatora AI z obrazów skrzynki i przycisku przesłanych przez użytkownika. Szczegóły: [LOGO_COMPOSITION.md](LOGO_COMPOSITION.md). Poprzedni research porównawczy ikon w LOGO_REDESIGN.md zachowano jako zapis historyczny.

## Budowanie Windows

Sprawdzono [tworzenie i budowanie projektu](https://docs.geode-sdk.org/getting-started/create-mod/), [narzędzia C++](https://github.com/geode-sdk/docs/blob/main/getting-started/cpp-stuff.md), [konfigurację mod.json](https://docs.geode-sdk.org/mods/configuring/) i rzeczywisty `setup_geode_mod` SDK. Wynik tworzy oficjalny Geode CLI; nie jest to ręcznie nazwany plik DLL ani archiwum udające mod.

Na tym komputerze oficjalny instalator Build Tools zwrócił kod 1. Użyto następnie przejrzanego [skryptu portable-msvc autora mmozeiko](https://gist.github.com/mmozeiko/7f3162ec2988e81e56d5c4e22cde9977), który pobrał paczki Microsoft i zweryfikował ich sumy SHA-256 względem manifestu Microsoft. Narzędzia rozpakowano wewnątrz projektu. Nie są dystrybuowane w ZIP moda.

Kompilator: MSVC 19.44.35229; narzędzia 14.44.35207; Windows SDK 10.0.26100.0; CMake 4.5.0-rc1; Ninja 1.13.2. Kompilacja x64, C++23, RelWithDebInfo. `DONT_INSTALL` w CMake zapobiega instalacji moda podczas budowania.
