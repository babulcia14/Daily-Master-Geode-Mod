# Raport testów Daily Master 1.0.0

## Aktualna grafika — kompozycja obrazów użytkownika bez AI

Najnowsza wersja zastępuje wcześniejsze logo niebieską skrzynką ze złotym zamkiem na niebieskim przycisku. Opis: [LOGO_COMPOSITION.md](LOGO_COMPOSITION.md). Poniższe starsze opisy gwiazdy i błyskawicy dotyczą poprzedniej, odrzuconej grafiki.

- PASS: zachowano bajtowo oba dostarczone obrazy w `artwork/source/`.
- PASS: wykonano skład bez generatora AI; wyeksportowano PNG 512/256 oraz źródło SVG z wektorową ramką i osadzonym PNG skrzynki.
- PASS: obejrzano logo 256 px i miniatury 24/32/35/48/64/96 px na dwóch tłach; przy 24 px drobne detale okuć tracą czytelność.
- PASS: oficjalny CLI poprawnie przepakował moda; `verify_package.py` potwierdził CRC, metadane, DLL i wymiary PNG 512/256/128/64.
- PASS: logo wewnątrz paczki jest identyczne z nowym `logo.png` projektu.
- PASS: pliki źródłowe C++, biblioteka DLL i `mod.json` są identyczne z wersją sprzed zmiany grafiki.
- NOT TESTED: instalacja i wygląd w uruchomionej grze; nadal odłożone na prośbę użytkownika.

Data testów kodu: 17.10.2026. Aktualizacja grafiki i ponowna kontrola paczki: 18.10.2026. Platforma docelowa: Windows x64, GD 2.2081, Geode 5.11.2.

**Wynik:** projekt został rzeczywiście skompilowany i spakowany przez oficjalny Geode CLI. Testy reguł odbioru i statyczna kontrola paczki przeszły. **Nie wykonano testu moda w działającej grze.** Użytkownik wybrał przygotowanie plików i odłożenie testu w grze na później. Nie zainstalowano moda w bieżącej grze i nie zmieniano jej zapisów.

## Wykonane

Poniższe testy kodu dotyczą kompilacji z 17.10.2026. Zakres kontroli wykonanej po wymianie logo znajduje się na końcu raportu.

| Sprawdzenie | Wynik | Zakres dowodu |
| --- | --- | --- |
| Odczyt wersji lokalnego GD | PASS | Znacznik PE potwierdza 2.2081; odczyt bez zmiany pliku. |
| Odczyt wersji Geode | PASS | 5.11.2, oficjalne SDK tej samej wersji. |
| Weryfikacja rzeczywistych nazw API | PASS | Nagłówki wygenerowane z bindings przypiętych do rewizji wydania; brak wymyślonych metod. |
| Analiza ścieżki nagrody | PASS | Odczyt kodu istniejącej gry potwierdził warunki odbioru i konieczność przekazania prawdziwego przycisku. To nie był test wykonania operacji. |
| Konfiguracja CMake | PASS | Znaleziono MSVC, SDK Geode i Node IDs. |
| Kompilacja i linkowanie | PASS | Wygenerowano `aer.daily_master.dll` dla x64, RelWithDebInfo; końcowa kompilacja bez ostrzeżeń i błędów w logu. |
| Pakowanie | PASS | Oficjalny CLI: `Successfully packaged aer.daily_master.geode`. |
| Testy C++ zasad odbioru | PASS | 112 sprawdzeń, 1 test CTest; `100% tests passed`. |
| Kontrola archiwum moda | PASS | CRC, unikalne i bezpieczne ścieżki, wymagane pliki. |
| Metadane i ustawienia | PASS | ID, wersja, jawna docelowa wersja GD, zależność Node IDs, cztery opcje bool. |
| Biblioteka w paczce | PASS | Nagłówki MZ/PE, maszyna AMD64, znacznik DLL. |
| Zgodność importów Geode | PASS | Wszystkie nazwane importy z Geode.dll istnieją w zainstalowanej bibliotece 5.11.2. |
| Zasoby PNG | PASS | Logo 512×512; przycisk UHD/HD/SD 256/128/64; źródła RGBA z przezroczystością. |
| Podgląd pierwszego logo (17.10) | ZASTĄPIONE | Pierwotną grafikę z kalendarzem użytkownik odrzucił. Wyniki kontroli nowego logo opisano w LOGO_REDESIGN.md. |
| Składnia skryptów PowerShell | PASS | `Build.ps1` i `Install.ps1` poprawnie parsowane. Budowanie faktycznie wykonane. |
| Kontrola kodu pod kątem atrap | PASS | Brak TODO w kluczowych funkcjach; przyciski mają podłączone operacje. Brak własnych wywołań dopisujących walutę lub procenty. |

Testy zasad odbioru obejmują: brak poziomu, 0%, 99%, 100% z gotową nagrodą, już odebraną nagrodę, zero gwiazdek, Weekly, Event, ID pobierania -1, nieprawidłowe procenty, nieprawidłowe gwiazdki oraz brak rzeczywistego ID poziomu. Dodatkowo sprawdzono wszystkie wartości normalnego postępu od 0 do 99. Nie tworzą one fikcyjnego zapisu gry — są testami funkcji kwalifikującej dane.

## Niewykonane — do sprawdzenia później w grze

| Próba | Oczekiwane zachowanie |
| --- | --- |
| Pierwsze uruchomienie z modem | Gra ładuje się; ikona pojawia się w dolnym menu. |
| Panel w oknie i na pełnym ekranie | Czytelny układ, brak nałożenia etykiet, działające przyciski myszy. |
| Zapis ustawień | Po zmianie przełączników, normalnym zamknięciu i ponownym uruchomieniu wartości pozostają takie same. |
| Brak ukończonego Daily | Brak odbioru i brak zmian walut. |
| Daily ukończony tylko w Practice | Brak odbioru nagrody bez normalnego 100%. |
| Rzeczywiste 100% i nieodebrana nagroda | Automat uruchamia natywny przycisk; gra przyznaje nagrodę i pokazuje animację. |
| Ponowne otwarcie tego samego Daily | Brak kolejnego odbioru tej samej nagrody. |
| Auto Claim wyłączone | Brak automatycznego kliknięcia; ręczny przycisk gry pozostaje dostępny. |
| Notifications wyłączone | Brak dodatkowego komunikatu moda; animacja gry pozostaje. |
| Check on Startup wyłączone | Brak automatycznego sprawdzania i otwierania Daily z menu. |
| Brak internetu / przekroczenie czasu | Czytelny komunikat, brak zawieszenia, lokalny status nadal dostępny. |
| Zamknięcie strony podczas żądania | Brak odwołania do usuniętego okna. |
| Inne mody menu / tekstur | Poprawny przycisk i brak konfliktów. Tego nie gwarantuje sama kompilacja. |
| Zmiana konta GD | Last Claim pokazuje historię właściwego konta. |
| Instalator pomocniczy | Kopiowanie do rzeczywistej instalacji i sprawdzenie sumy; wykonanie odłożono razem z testem w grze. |

Nie należy przedstawiać tego raportu jako potwierdzenia pełnego testu funkcjonalnego. Do próby odbioru potrzebna jest nagroda rzeczywiście zdobyta przez gracza; nie przygotowywano jej sztucznie.

## Odtworzenie kontroli bez gry

Uruchom z przygotowanym kompilatorem:

```powershell
.\scripts\Build.ps1 -TestsOnly
python .\scripts\verify_package.py .\build\aer.daily_master.geode
```

Pierwsze polecenie kompiluje i uruchamia test C++. Drugie odczytuje paczkę `.geode` bez jej instalacji. Instrukcje otwarcia terminala i konfiguracji narzędzi są w README.md.

## Ograniczenia i rozwiązane problemy środowiska

- Pierwsze uruchomienie oficjalnego instalatora Microsoft zakończyło się kodem 1; użyto przenośnych narzędzi pobranych z serwerów Microsoft do folderu projektu.
- Pierwsza konfiguracja Geode CLI wymagała profilu gry. Dodano profil `DailyMaster-local`; `DONT_INSTALL` pozostało włączone.
- Piaskownica uniemożliwiała pracę komponentu diagnostycznego MSVC (C1902). Uruchomienie kompilacji poza piaskownicą rozwiązało problem.
- W przeglądzie kodu znaleziono ryzyko utraty skali popupu przez natywną animację. Zastosowano własną krótką animację z zachowaniem obliczonej skali; finalny kod został ponownie skompilowany.
- Pozostaje niepewność dotycząca zachowania w rzeczywistym środowisku gry i interakcji z innymi modami, do czasu wykonania wymienionych prób.

## Wymiana logo — wykonane 18.10.2026

| Sprawdzenie | Oczekiwany rezultat | Rzeczywisty rezultat | Wynik |
| --- | --- | --- | --- |
| Format i rozmiary | Kwadratowy PNG, alfa, warianty 512/256 | Oryginał 1254 × 1254 RGBA; eksporty 512 i 256; alfa zawiera wartości 0 i 255 | PASS |
| Czytelność poza grą | Wyraźna skrzynka i gwiazda przy rozmiarze przycisku | Obejrzano arkusz 24/32/35/48/64/128 px na dwóch tłach. Przy 32–35 px oba główne motywy są czytelne; przy 24 px błyskawica staje się małym akcentem | PASS z ograniczeniem 24 px |
| Ponowne pakowanie CLI | Nowa ikona w prawdziwej paczce `.geode` | Oficjalny CLI zakończył pakowanie sukcesem | PASS |
| Kontrola archiwum | Poprawne CRC, metadane, DLL i wymiary tekstur | `verify_package.py` zakończył wszystkie kontrole sukcesem | PASS |
| Aktualność obrazów w paczce | Nowy znak zamiast starego kalendarza | `logo.png` zgodne bajtowo z nowym plikiem projektu; UHD zgodne pikselowo ze źródłem | PASS |
| Tekstury jakości gry | 64/128/256 px z przezroczystością | Wszystkie trzy PNG odczytane z paczki, prawidłowe wymiary i kanał alfa | PASS |
| Zachowanie funkcji | Identyczny kod C++ i skompilowana DLL | Porównanie SHA-256 wszystkich plików `src` oraz bajtów DLL przed i po zmianie: identyczne | PASS |
| Zakres zmian paczki | Wyłącznie obrazy i opis zmiany | Zmieniły się tylko `logo.png`, trzy warianty `daily-master*.png` oraz `changelog.md`; `mod.json` i ustawienia identyczne | PASS |
| Nowa ikona w uruchomionej grze | Poprawny wygląd i obsługa przycisku | Nie uruchamiano ani nie instalowano moda; użytkownik odłożył test w grze | NOT TESTED |

SHA-256 niezmienionej biblioteki `aer.daily_master.dll`:
`0b9917063d45503c7a5256154d33e8aca2a20c39cd0888c6dbddc9d326d8faaf`.

Przy zmianie samych obrazów nie kompilowano ponownie C++ ani nie przedstawiano wcześniejszych testów reguł jako ponownie uruchomionych. Zaktualizowano pliki źródłowe grafiki, instrukcje rozpoznania nowego przycisku oraz wydanie ZIP. Research wizualny i źródła: [LOGO_REDESIGN.md](LOGO_REDESIGN.md).
