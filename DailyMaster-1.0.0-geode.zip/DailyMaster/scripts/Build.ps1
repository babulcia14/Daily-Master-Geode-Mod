param([switch]$TestsOnly)
$ErrorActionPreference = 'Stop'
$project = Split-Path $PSScriptRoot -Parent
$tools = Join-Path (Split-Path $project -Parent) '.tools'

# A portable compiler prepared alongside this project takes precedence.
$portable = Join-Path $tools 'msvc'
if (Test-Path (Join-Path $portable 'setup_x64.bat')) {
    $vc = Get-ChildItem (Join-Path $portable 'VC/Tools/MSVC') -Directory | Sort-Object Name -Descending | Select-Object -First 1
    $sdkRoot = Join-Path $portable 'Windows Kits/10'
    $sdk = Get-ChildItem (Join-Path $sdkRoot 'Include') -Directory | Sort-Object Name -Descending | Select-Object -First 1
    $env:PATH = "$($vc.FullName)\bin\Hostx64\x64;$sdkRoot\bin\$($sdk.Name)\x64;$tools\ninja;$tools\cli;C:\Program Files\CMake\bin;$env:PATH"
    $env:INCLUDE = "$($vc.FullName)\include;$sdkRoot\Include\$($sdk.Name)\ucrt;$sdkRoot\Include\$($sdk.Name)\shared;$sdkRoot\Include\$($sdk.Name)\um;$sdkRoot\Include\$($sdk.Name)\winrt"
    $env:LIB = "$($vc.FullName)\lib\x64;$sdkRoot\Lib\$($sdk.Name)\ucrt\x64;$sdkRoot\Lib\$($sdk.Name)\um\x64"
}
if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) {
    throw 'Nie znaleziono CMake. Instrukcja instalacji jest w README.md.'
}
if (-not (Get-Command cl -ErrorAction SilentlyContinue) -and -not (Get-Command clang-cl -ErrorAction SilentlyContinue)) {
    throw 'Uruchom ten skrypt w x64 Native Tools Command Prompt lub skonfiguruj kompilator wedlug README.md.'
}
$build = Join-Path $project $(if ($TestsOnly) { 'build-tests' } else { 'build' })
$cmakeArgs = @('-S', $project, '-B', $build, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=RelWithDebInfo')
if (Get-Command clang-cl -ErrorAction SilentlyContinue) {
    $cmakeArgs += @('-DCMAKE_CXX_COMPILER=clang-cl', '-DCMAKE_C_COMPILER=clang-cl')
} else {
    $cmakeArgs += @('-DCMAKE_CXX_COMPILER=cl', '-DCMAKE_C_COMPILER=cl')
}
if ($TestsOnly) {
    $cmakeArgs += '-DDAILY_MASTER_TESTS_ONLY=ON'
} else {
    if (Test-Path (Join-Path $tools 'geode/CMakeLists.txt')) { $env:GEODE_SDK = Join-Path $tools 'geode' }
    if (Test-Path (Join-Path $tools 'bindings/CMakeLists.txt')) {
        $cmakeArgs += "-DGEODE_BINDINGS_REPO_PATH=$tools/bindings"
    }
    if (-not $env:GEODE_SDK) { throw 'Brak GEODE_SDK. Uruchom geode sdk install wedlug README.md.' }
    $env:CPM_SOURCE_CACHE = Join-Path $tools 'cpm-cache'
}
& cmake @cmakeArgs
if ($LASTEXITCODE -ne 0) { throw 'Konfiguracja nie powiodla sie. Przeczytaj blad powyzej.' }
& cmake --build $build --config RelWithDebInfo --parallel 3
if ($LASTEXITCODE -ne 0) { throw 'Kompilacja nie powiodla sie. Przeczytaj blad powyzej.' }
if ($TestsOnly) {
    & ctest --test-dir $build --output-on-failure
    if ($LASTEXITCODE -ne 0) { throw 'Testy nie przeszly.' }
} else {
    Write-Host "Gotowy mod: $build\aer.daily_master.geode" -ForegroundColor Green
}
