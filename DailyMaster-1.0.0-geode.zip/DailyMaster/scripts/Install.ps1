param([string]$GameDir)
$ErrorActionPreference = 'Stop'
$project = Split-Path $PSScriptRoot -Parent
try {
    if (Get-Process GeometryDash -ErrorAction SilentlyContinue) {
        throw 'Gra jest uruchomiona. Zamknij Geometry Dash normalnie, a potem uruchom instalator ponownie.'
    }
    $package = Join-Path $project 'aer.daily_master.geode'
    if (-not (Test-Path -LiteralPath $package)) { $package = Join-Path $project 'build/aer.daily_master.geode' }
    if (-not (Test-Path -LiteralPath $package)) { throw 'Brak gotowego pliku aer.daily_master.geode obok instalatora lub w folderze build.' }
    if (-not $GameDir) {
        $candidates = [System.Collections.Generic.List[string]]::new()
        $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
        if (-not $steam) { $steam = Join-Path ${env:ProgramFiles(x86)} 'Steam' }
        $candidates.Add((Join-Path $steam 'steamapps/common/Geometry Dash'))
        $libraries = Join-Path $steam 'steamapps/libraryfolders.vdf'
        if (Test-Path -LiteralPath $libraries) {
            $vdf = Get-Content -LiteralPath $libraries -Raw
            foreach ($match in [regex]::Matches($vdf, '"path"\s+"([^\"]+)"')) {
                $library = $match.Groups[1].Value.Replace('\\', '\')
                $candidates.Add((Join-Path $library 'steamapps/common/Geometry Dash'))
            }
        }
        $GameDir = $candidates | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'GeometryDash.exe') } | Select-Object -First 1
    }
    if (-not $GameDir -or -not (Test-Path -LiteralPath (Join-Path $GameDir 'Geode.dll'))) {
        throw 'Nie znaleziono Geometry Dash z Geode. Uzyj recznej instalacji opisanej w README.md.'
    }
    $stream = [System.IO.File]::OpenRead((Join-Path $GameDir 'GeometryDash.exe'))
    $reader = [System.IO.BinaryReader]::new($stream)
    try {
        $stream.Position = 60
        $peOffset = $reader.ReadInt32()
        $stream.Position = $peOffset + 8
        $timestamp = $reader.ReadUInt32()
    } finally { $reader.Dispose() }
    if ($timestamp -ne 1768959392) {
        throw 'Ta paczka wymaga Geometry Dash 2.2081. Wykryto inna wersje gry; potrzebna jest zgodna wersja moda.'
    }
    $mods = Join-Path $GameDir 'geode/mods'
    if (-not (Test-Path -LiteralPath $mods -PathType Container)) { throw 'Brak folderu geode/mods. Uruchom najpierw gre z Geode.' }
    $target = Join-Path $mods 'aer.daily_master.geode'
    if (Test-Path -LiteralPath $target) {
        $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
        Copy-Item -LiteralPath $target -Destination "$target.$stamp.bak"
    }
    Copy-Item -LiteralPath $package -Destination $target -Force
    if ((Get-FileHash -LiteralPath $package).Hash -ne (Get-FileHash -LiteralPath $target).Hash) {
        throw 'Kontrola skopiowanego pliku nie powiodla sie. Uruchom instalator ponownie.'
    }
    Write-Host "Zainstalowano Daily Master: $target" -ForegroundColor Green
    Write-Host 'Teraz uruchom Geometry Dash ze Steam i kliknij zielona ikone kalendarza w dolnym menu.'
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
