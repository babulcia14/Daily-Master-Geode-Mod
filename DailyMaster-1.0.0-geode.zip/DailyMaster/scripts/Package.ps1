$ErrorActionPreference = 'Stop'
$project = Split-Path $PSScriptRoot -Parent
$output = Join-Path (Split-Path $project -Parent) 'dist'
$package = Join-Path $project 'build/aer.daily_master.geode'
if (-not (Test-Path -LiteralPath $package)) { throw 'Najpierw zbuduj moda przez ZBUDUJ.cmd.' }
New-Item -ItemType Directory -Force -Path $output | Out-Null
Copy-Item -LiteralPath $package -Destination (Join-Path $output 'aer.daily_master.geode') -Force

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zipPath = Join-Path $output 'DailyMaster-1.0.0-komplet.zip'
$zip = [System.IO.Compression.ZipArchive]::new(
    [System.IO.File]::Open($zipPath, [System.IO.FileMode]::Create),
    [System.IO.Compression.ZipArchiveMode]::Create)
try {
    Get-ChildItem -LiteralPath $project -Recurse -File | ForEach-Object {
        $relative = $_.FullName.Substring($project.Length + 1).Replace('\', '/')
        if ($relative -notmatch '^(build[^/]*|\.geode_cache|\.cache|\.git)/' -and
            $relative -notmatch '(^|/)__pycache__/' -and
            $relative -notmatch '\.(geode|dll|pdb|lib|exp|pyc)$') {
            [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
                $zip, $_.FullName, "DailyMaster/$relative", [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
        }
    }
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
        $zip, $package, 'DailyMaster/aer.daily_master.geode', [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
} finally { $zip.Dispose() }

$hashes = @('aer.daily_master.geode', 'DailyMaster-1.0.0-komplet.zip') | ForEach-Object {
    $hash = Get-FileHash -LiteralPath (Join-Path $output $_) -Algorithm SHA256
    "$($hash.Hash.ToLower())  $_"
}
$hashes | Set-Content -LiteralPath (Join-Path $output 'SHA256SUMS.txt') -Encoding ascii
Write-Host "Gotowe pliki: $output" -ForegroundColor Green
