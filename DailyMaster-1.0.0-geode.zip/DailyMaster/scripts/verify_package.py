"""Static checks for a real Geode Windows package; does not launch the game."""
import json
import struct
import sys
import zipfile
from pathlib import Path


def check(condition, description):
    if not condition:
        raise SystemExit('FAIL: ' + description)
    print('PASS: ' + description)


package = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / 'build/aer.daily_master.geode'
with zipfile.ZipFile(package) as archive:
    names = archive.namelist()
    check(archive.testzip() is None, 'archive CRC')
    check(len(names) == len(set(names)), 'no duplicate archive paths')
    check(all(not name.startswith(('/', '\\')) and '..' not in name.replace('\\', '/').split('/') for name in names), 'safe archive paths')
    metadata = json.loads(archive.read('mod.json'))
    check(metadata['id'] == 'aer.daily_master' and metadata['version'] == '1.0.0', 'mod identity/version')
    check(metadata['geode'] == '5.11.2' and metadata['gd'] == {'win': '2.2081'}, 'explicit supported versions')
    keys = {'auto-claim-daily', 'notifications', 'check-on-startup', 'debug-logging'}
    check(set(metadata['settings']) == keys and all(v['type'] == 'bool' and type(v['default']) is bool for v in metadata['settings'].values()), 'four real boolean settings')
    check(metadata['dependencies']['geode.node-ids'] == '>=1.23.3', 'Node IDs dependency')
    for name in ['about.md', 'changelog.md', 'logo.png', 'aer.daily_master.dll']:
        check(name in names, f'packaged {name}')
    dll = archive.read('aer.daily_master.dll')
    pe = struct.unpack_from('<I', dll, 60)[0]
    check(dll[:2] == b'MZ' and dll[pe:pe+4] == b'PE\x00\x00', 'real Windows PE binary')
    check(struct.unpack_from('<H', dll, pe+4)[0] == 0x8664, 'x64 machine type')
    check(bool(struct.unpack_from('<H', dll, pe+22)[0] & 0x2000), 'DLL characteristic')
    images = {
        'logo.png': (512, 512),
        'resources/aer.daily_master/daily-master.png': (64, 64),
        'resources/aer.daily_master/daily-master-hd.png': (128, 128),
        'resources/aer.daily_master/daily-master-uhd.png': (256, 256),
    }
    for name, dimensions in images.items():
        data = archive.read(name)
        check(data[:8] == b'\x89PNG\r\n\x1a\n' and struct.unpack_from('>II', data, 16) == dimensions, f'PNG dimensions {name} {dimensions}')
    check(not any(name.endswith(('.cpp', '.hpp', '.pdb', '.exe')) for name in names), 'no sources, debug database or installers in mod package')
print('Package validation passed. This is not a runtime test.')
