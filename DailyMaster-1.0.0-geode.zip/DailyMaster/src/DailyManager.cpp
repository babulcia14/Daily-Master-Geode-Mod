#include "DailyManager.hpp"
#include "Settings.hpp"
#include <Geode/binding/DailyLevelNode.hpp>
#include <Geode/binding/DailyLevelPage.hpp>
#include <Geode/binding/GameLevelManager.hpp>
#include <Geode/binding/GameStatsManager.hpp>
#include <Geode/binding/GJAccountManager.hpp>
#include <Geode/ui/Notification.hpp>

using namespace geode::prelude;
namespace daily {
namespace {
CCMenuItem* findClaimButton(CCNode* root, DailyLevelNode* owner) {
    if (!root || !root->isVisible()) return nullptr;
    if (auto item = typeinfo_cast<CCMenuItem*>(root);
        item && item->isEnabled() && item->m_pListener == owner &&
        item->m_pfnSelector == menu_selector(DailyLevelNode::onClaimReward))
        return item;
    for (auto child : CCArrayExt<CCNode*>(root->getChildren()))
        if (auto item = findClaimButton(child, owner)) return item;
    return nullptr;
}
}

DailyManager& DailyManager::get() {
    // Game managers and this delegate live until process exit. The scheduler
    // retains the target. Never keep a pointer to a page after it is closed.
    static auto instance = [] {
        auto manager = new DailyManager;
        manager->init();
        return manager;
    }();
    return *instance;
}

bool DailyManager::init() {
    if (!CCNode::init()) return false;
    CCDirector::sharedDirector()->getScheduler()->scheduleSelector(
        schedule_selector(DailyManager::tick), this, 1.f, false);
    return true;
}

RewardFacts DailyManager::facts(GJGameLevel* level) const {
    if (!level) return {};
    auto id = level->m_dailyID.value();
    return { id, level->m_levelID.value(), level->getNormalPercent(),
        level->m_stars.value(), GameStatsManager::sharedState()->hasCompletedDailyLevel(id) };
}

GJGameLevel* DailyManager::activeLevel() const {
    auto manager = GameLevelManager::sharedState();
    auto id = manager->getActiveDailyID(GJTimedLevelType::Daily);
    if (id <= 0) id = manager->getDailyID(GJTimedLevelType::Daily);
    return id > 0 && id < 100000 ? manager->getSavedDailyLevel(id) : nullptr;
}

std::string DailyManager::statusText() const {
    auto f = facts(activeLevel());
    switch (classify(f)) {
        case RewardState::NoLevel: return "Otworz Daily, aby pobrac poziom";
        case RewardState::InProgress: return fmt::format("Daily #{}: {}% / 100%", f.dailyID, f.normalPercent);
        case RewardState::Unrated: return "Ten Daily nie ma nagrody";
        case RewardState::Ready: return fmt::format("Daily #{}: nagroda gotowa!", f.dailyID);
        case RewardState::Claimed: return fmt::format("Daily #{}: nagroda odebrana", f.dailyID);
        case RewardState::Invalid: return "Nieprawidlowe dane Daily - brak odbioru";
    }
    return "Brak danych";
}

std::string DailyManager::networkText() const { return m_network; }

void DailyManager::menuReady() {
    if (m_seenMenu) return;
    m_seenMenu = true;
    if (settings::checkOnStartup()) checkNow();
}

void DailyManager::checkNow() {
    auto now = Clock::now();
    if (m_pending) return;
    if (m_lastRequest != Clock::time_point{} && now - m_lastRequest < std::chrono::seconds(30)) {
        m_network = "Odczekaj 30 s miedzy sprawdzeniami";
        return;
    }
    auto levels = GameLevelManager::sharedState();
    if (levels->m_GJDailyLevelDelegate && levels->m_GJDailyLevelDelegate != this) {
        m_network = "Gra sprawdza Daily w innym oknie";
        return;
    }
    m_pending = true;
    m_lastRequest = m_requestStarted = now;
    m_network = "Serwer: sprawdzanie...";
    levels->m_GJDailyLevelDelegate = this;
    if (!levels->getGJDailyLevelState(GJTimedLevelType::Daily)) {
        m_pending = false;
        releaseDelegate();
        m_network = "Zapytanie gry juz trwa. Sprobuj pozniej";
    }
    if (settings::debugLogging()) log::info("Daily Master: native daily status request, pending={}", m_pending);
}

void DailyManager::releaseDelegate() {
    auto levels = GameLevelManager::sharedState();
    if (levels->m_GJDailyLevelDelegate == this) levels->m_GJDailyLevelDelegate = nullptr;
}

void DailyManager::dailyStatusFinished(GJTimedLevelType type) {
    if (type != GJTimedLevelType::Daily) return;
    m_pending = false;
    releaseDelegate();
    auto id = GameLevelManager::sharedState()->getDailyID(type);
    m_network = fmt::format("Serwer: aktualny Daily #{}", id);
    if (settings::debugLogging()) log::info("Daily Master: daily status loaded, daily={}", id);
}

void DailyManager::dailyStatusFailed(GJTimedLevelType type, GJErrorCode errorType) {
    if (type != GJTimedLevelType::Daily) return;
    m_pending = false;
    releaseDelegate();
    m_network = "Brak polaczenia - status z zapisu gry";
    if (settings::debugLogging()) log::warn("Daily Master: daily request failed ({})", static_cast<int>(errorType));
}

void DailyManager::tick(float) {
    if (m_pending && Clock::now() - m_requestStarted >= std::chrono::seconds(20)) {
        m_pending = false;
        releaseDelegate();
        m_network = "Brak odpowiedzi - status z zapisu gry";
    }
    auto status = statusText();
    if (status != m_lastStatus) {
        m_lastStatus = status;
        Mod::get()->setSavedValue("daily-status", status);
        if (settings::debugLogging()) log::info("Daily Master: {}", status);
    }
}

void DailyManager::tryAutoClaim(DailyLevelPage* page) {
    if (!settings::autoClaim() || m_claimInFlight || !page || !page->isRunning() ||
        page->m_type != GJTimedLevelType::Daily) return;
    auto node = page->m_dailyNode;
    if (!node || !node->isRunning() || node->m_unkBool || node->m_needsDownloading ||
        classify(facts(node->m_level)) != RewardState::Ready) return;
    auto button = findClaimButton(node, node);
    if (!button) return;

    // activate() supplies the real sender. onClaimReward(nullptr) would crash:
    // GD disables the sender after claiming. The original node can be removed
    // during activation, hence these owning references until the call returns.
    Ref<DailyLevelNode> keepNode = node;
    Ref<CCMenuItem> keepButton = button;
    m_claimInFlight = true;
    if (settings::debugLogging()) log::info("Daily Master: activating native claim, daily={}", node->m_level->m_dailyID.value());
    button->activate();
    m_claimInFlight = false;
}

void DailyManager::recordNativeClaim(GJGameLevel* level, bool wasClaimed, int accountID) {
    auto f = facts(level);
    if (wasClaimed || classify(f) != RewardState::Claimed || f.normalPercent != 100 || f.stars <= 0) return;
    settings::recordClaim(accountID, f.dailyID, f.levelID);
    if (settings::notifications()) Notification::create("Daily Master: nagroda odebrana!", NotificationIcon::Success)->show();
    if (settings::debugLogging()) log::info("Daily Master: native claim confirmed, daily={}", f.dailyID);
}

bool hasOpenModal(CCNode* root) {
    if (!root || !root->isVisible()) return false;
    if (typeinfo_cast<FLAlertLayer*>(root)) return true;
    for (auto child : CCArrayExt<CCNode*>(root->getChildren()))
        if (hasOpenModal(child)) return true;
    return false;
}

bool openDailyPage() {
    auto page = DailyLevelPage::create(GJTimedLevelType::Daily);
    if (!page) {
        Notification::create("Nie udalo sie otworzyc Daily", NotificationIcon::Error)->show();
        return false;
    }
    page->show();
    return true;
}
}
