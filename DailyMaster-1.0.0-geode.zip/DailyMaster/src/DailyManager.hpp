#pragma once
#include "RewardPolicy.hpp"
#include <Geode/Geode.hpp>
#include <Geode/binding/GJDailyLevelDelegate.hpp>
#include <chrono>

class DailyLevelPage;
class DailyLevelNode;

namespace daily {
class DailyManager final : public cocos2d::CCNode, public GJDailyLevelDelegate {
public:
    static DailyManager& get();
    bool init() override;
    void menuReady();
    void checkNow();
    void tick(float);
    RewardFacts facts(GJGameLevel* level) const;
    GJGameLevel* activeLevel() const;
    std::string statusText() const;
    std::string networkText() const;
    void tryAutoClaim(DailyLevelPage* page);
    void recordNativeClaim(GJGameLevel* level, bool wasClaimed, int accountID);
    void dailyStatusFinished(GJTimedLevelType type) override;
    void dailyStatusFailed(GJTimedLevelType type, GJErrorCode errorType) override;
private:
    using Clock = std::chrono::steady_clock;
    bool m_seenMenu = false;
    bool m_pending = false;
    bool m_claimInFlight = false;
    Clock::time_point m_lastRequest{};
    Clock::time_point m_requestStarted{};
    std::string m_network = "Serwer: jeszcze nie sprawdzono";
    std::string m_lastStatus;
    void releaseDelegate();
};

bool hasOpenModal(cocos2d::CCNode* root);
bool openDailyPage();
}
