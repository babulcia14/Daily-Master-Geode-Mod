#pragma once

namespace daily {
enum class RewardState { NoLevel, InProgress, Unrated, Ready, Claimed, Invalid };

struct RewardFacts {
    int dailyID = 0;
    int levelID = 0;
    int normalPercent = 0;
    int stars = 0;
    bool claimed = false;
};

// Mirrors the native Daily claim prerequisites, with an additional Daily-only
// boundary. Weekly IDs start at 100000; Event IDs start at 200000.
constexpr RewardState classify(RewardFacts const& f) {
    if (f.dailyID == 0 || f.levelID == 0) return RewardState::NoLevel;
    if (f.dailyID < 0 || f.dailyID >= 100000 || f.levelID < 0 ||
        f.normalPercent < 0 || f.normalPercent > 100 || f.stars < 0 || f.stars > 10)
        return RewardState::Invalid;
    if (f.claimed) return RewardState::Claimed;
    if (f.stars == 0) return RewardState::Unrated;
    if (f.normalPercent < 100) return RewardState::InProgress;
    return RewardState::Ready;
}
}
