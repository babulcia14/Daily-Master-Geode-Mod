#include "Settings.hpp"
#include <Geode/Geode.hpp>
#include <Geode/binding/GJAccountManager.hpp>
#include <ctime>
#include <iomanip>
#include <sstream>

using namespace geode::prelude;
namespace daily::settings {
bool autoClaim() { return Mod::get()->getSettingValue<bool>("auto-claim-daily"); }
bool notifications() { return Mod::get()->getSettingValue<bool>("notifications"); }
bool checkOnStartup() { return Mod::get()->getSettingValue<bool>("check-on-startup"); }
bool debugLogging() { return Mod::get()->getSettingValue<bool>("debug-logging"); }

void save() {
    if (auto result = Mod::get()->saveData(); result.isErr())
        log::warn("Daily Master: nie udalo sie zapisac ustawien: {}", result.unwrapErr());
}

void toggle(char const* key) {
    auto mod = Mod::get();
    mod->setSettingValue<bool>(key, !mod->getSettingValue<bool>(key));
    save();
}

std::string lastClaim() {
    auto account = GJAccountManager::sharedState()->m_accountID;
    return Mod::get()->getSavedValue<std::string>(
        fmt::format("last-claim-account-{}", account), "Jeszcze nie odebrano");
}

void recordClaim(int accountID, int dailyID, int levelID) {
    auto now = std::time(nullptr);
    std::tm local{};
    localtime_s(&local, &now);
    std::ostringstream stamp;
    stamp << std::put_time(&local, "%Y-%m-%d %H:%M:%S");
    auto mod = Mod::get();
    mod->setSavedValue(fmt::format("last-claim-account-{}", accountID),
        fmt::format("{} | Daily #{}", stamp.str(), dailyID));
    mod->setSavedValue("last-claim-unix", static_cast<int64_t>(now));
    mod->setSavedValue("last-claim-daily-id", dailyID);
    mod->setSavedValue("last-claim-level-id", levelID);
    save();
}
}
