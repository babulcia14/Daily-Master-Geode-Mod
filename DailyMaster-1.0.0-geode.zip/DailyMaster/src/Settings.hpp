#pragma once
#include <string>

namespace daily::settings {
bool autoClaim();
bool notifications();
bool checkOnStartup();
bool debugLogging();
void toggle(char const* key);
void save();
std::string lastClaim();
void recordClaim(int accountID, int dailyID, int levelID);
}
