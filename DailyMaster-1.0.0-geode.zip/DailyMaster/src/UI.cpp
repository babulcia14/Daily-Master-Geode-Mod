#include "UI.hpp"
#include "DailyManager.hpp"
#include "Settings.hpp"
#include <Geode/Geode.hpp>
#include <Geode/binding/ButtonSprite.hpp>
#include <Geode/binding/CCMenuItemToggler.hpp>
#include <Geode/ui/GeodeUI.hpp>

using namespace geode::prelude;
namespace daily {
namespace {
constexpr std::array<char const*, 4> keys = {
    "auto-claim-daily", "notifications", "check-on-startup", "debug-logging" };

CCLabelBMFont* label(CCNode* parent, char const* text, CCPoint pos,
    float scale, char const* font = "bigFont.fnt", float width = 330.f) {
    auto result = CCLabelBMFont::create(text, font);
    result->setPosition(pos);
    result->limitLabelWidth(width, scale, .12f);
    parent->addChild(result, 2);
    return result;
}

void updateLabel(CCLabelBMFont* node, std::string const& text, float scale, float width) {
    node->setString(text.c_str());
    node->limitLabelWidth(width, scale, .12f);
}
}

DailyPopup* DailyPopup::create() {
    auto popup = new DailyPopup;
    if (popup->init()) { popup->autorelease(); return popup; }
    delete popup;
    return nullptr;
}

bool DailyPopup::init() {
    if (!Popup::init(380.f, 290.f, "GJ_square01.png")) return false;
    m_noElasticity = true; // Native elasticity always ends at 1.0, losing small-window scaling.
    setID("daily-master-popup"_spr);
    setTitle("Daily Master", "goldFont.fnt", .8f, 22.f);
    auto win = CCDirector::sharedDirector()->getWinSize();
    m_mainLayer->setScale(std::min({1.f, (win.width - 24.f) / 380.f, (win.height - 24.f) / 290.f}));

    auto panel = extension::CCScale9Sprite::create("square02_small.png");
    panel->setColor({10, 45, 29});
    panel->setOpacity(210);
    panel->setContentSize({344, 87});
    panel->setPosition({190, 204});
    m_mainLayer->addChild(panel);
    label(m_mainLayer, "Daily Status", {190, 234}, .36f, "goldFont.fnt");
    m_status = label(m_mainLayer, "", {190, 215}, .42f);
    m_network = label(m_mainLayer, "", {190, 196}, .33f, "chatFont.fnt");
    label(m_mainLayer, "Last Claim", {60, 175}, .3f, "goldFont.fnt", 75);
    m_lastClaim = label(m_mainLayer, "", {233, 175}, .3f, "chatFont.fnt", 235);

    constexpr std::array<char const*, 4> names = {
        "Auto Claim Daily", "Notifications", "Check on Startup", "Debug Logging" };
    for (int i = 0; i < 4; ++i) {
        auto y = 143.f - i * 23.f;
        auto text = label(m_mainLayer, names[i], {39, y}, .38f, "bigFont.fnt", 250);
        text->setAnchorPoint({0, .5f});
        auto toggle = CCMenuItemToggler::createWithStandardSprites(this,
            menu_selector(DailyPopup::onToggle), .55f);
        toggle->setTag(i);
        toggle->setPosition({331, y});
        toggle->setID(std::string(keys[i]) + "-toggle");
        m_buttonMenu->addChild(toggle);
        m_toggles[i] = toggle;
    }

    auto addButton = [this](char const* text, float x, SEL_MenuHandler handler) {
        auto sprite = ButtonSprite::create(text, 90, true, "bigFont.fnt", "GJ_button_01.png", 28, .48f);
        auto item = CCMenuItemSpriteExtra::create(sprite, this, handler);
        item->setPosition({x, 42});
        m_buttonMenu->addChild(item);
    };
    addButton("Sprawdz", 77, menu_selector(DailyPopup::onCheck));
    addButton("Daily", 190, menu_selector(DailyPopup::onDaily));
    addButton("Opcje", 303, menu_selector(DailyPopup::onSettings));
    auto foot = label(m_mainLayer, "Nagroda wymaga 100% w zwyklym trybie Daily", {190, 16}, .31f, "chatFont.fnt");
    foot->setColor({204, 237, 188});
    refresh(0);
    schedule(schedule_selector(DailyPopup::refresh), .5f);
    return true;
}

void DailyPopup::show() {
    Popup::show();
    auto scale = m_mainLayer->getScale();
    m_mainLayer->setScale(scale * .96f);
    m_mainLayer->runAction(CCEaseSineOut::create(CCScaleTo::create(.18f, scale)));
}

void DailyPopup::refresh(float) {
    auto& manager = DailyManager::get();
    updateLabel(m_status, manager.statusText(), .42f, 320);
    updateLabel(m_network, manager.networkText(), .33f, 320);
    updateLabel(m_lastClaim, settings::lastClaim(), .3f, 235);
    bool ready = classify(manager.facts(manager.activeLevel())) == RewardState::Ready;
    m_status->setColor(ready ? ccColor3B{170, 255, 93} : ccColor3B{255, 255, 255});
    for (size_t i = 0; i < m_toggles.size(); ++i)
        m_toggles[i]->toggle(Mod::get()->getSettingValue<bool>(keys[i]));
}

void DailyPopup::onToggle(CCObject* sender) {
    auto index = static_cast<CCNode*>(sender)->getTag();
    if (index >= 0 && index < static_cast<int>(keys.size())) settings::toggle(keys[index]);
    // Native togglers change their state after the callback; refresh on next tick.
}
void DailyPopup::onCheck(CCObject*) { DailyManager::get().checkNow(); refresh(0); }
void DailyPopup::onDaily(CCObject*) { if (openDailyPage()) onClose(nullptr); }
void DailyPopup::onSettings(CCObject*) { openSettingsPopup(Mod::get(), true); }

void addMenuButton(CCNode* layer) {
    auto menu = layer->getChildByID("bottom-menu");
    if (!menu || menu->getChildByID("daily-master-button"_spr)) return;
    auto logo = CCSprite::create("daily-master.png"_spr);
    if (!logo) return;
    logo->setScale(35.f / logo->getContentSize().width);
    auto button = CCMenuItemExt::createSpriteExtra(logo, [](auto*) {
        if (auto popup = DailyPopup::create()) popup->show();
    });
    button->setID("daily-master-button"_spr);
    menu->addChild(button);
    menu->updateLayout();
}
}
