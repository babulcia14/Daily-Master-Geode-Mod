#pragma once
#include <Geode/ui/Popup.hpp>
#include <array>

class CCMenuItemToggler;

namespace daily {
class DailyPopup final : public geode::Popup {
public:
    static DailyPopup* create();
    void show() override;
private:
    bool init();
    void refresh(float);
    void onToggle(cocos2d::CCObject* sender);
    void onCheck(cocos2d::CCObject*);
    void onDaily(cocos2d::CCObject*);
    void onSettings(cocos2d::CCObject*);
    cocos2d::CCLabelBMFont* m_status = nullptr;
    cocos2d::CCLabelBMFont* m_lastClaim = nullptr;
    cocos2d::CCLabelBMFont* m_network = nullptr;
    std::array<CCMenuItemToggler*, 4> m_toggles{};
};
void addMenuButton(cocos2d::CCNode* menuLayer);
}
