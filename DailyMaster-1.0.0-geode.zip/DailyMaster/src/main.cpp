#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/DailyLevelPage.hpp>
#include <Geode/binding/GameStatsManager.hpp>
#include <Geode/binding/GJAccountManager.hpp>
#include "DailyManager.hpp"
#include "Settings.hpp"
#include "UI.hpp"

using namespace geode::prelude;

class $modify(DailyMasterMenu, MenuLayer) {
    struct Fields { bool startupChecked = false; int openedDaily = 0; };
    bool init() {
        if (!MenuLayer::init()) return false;
        daily::addMenuButton(this);
        schedule(schedule_selector(DailyMasterMenu::dailyMasterTick), 1.f);
        return true;
    }
    void dailyMasterTick(float) {
        if (daily::hasOpenModal(CCDirector::sharedDirector()->getRunningScene())) return;
        auto& manager = daily::DailyManager::get();
        if (!m_fields->startupChecked) {
            m_fields->startupChecked = true;
            manager.menuReady();
        }
        if (!daily::settings::autoClaim() || !daily::settings::checkOnStartup()) return;
        auto facts = manager.facts(manager.activeLevel());
        if (daily::classify(facts) == daily::RewardState::Ready && m_fields->openedDaily != facts.dailyID) {
            m_fields->openedDaily = facts.dailyID;
            daily::openDailyPage();
        }
    }
};

class $modify(DailyMasterPage, DailyLevelPage) {
    bool init(GJTimedLevelType type) {
        if (!DailyLevelPage::init(type)) return false;
        if (type == GJTimedLevelType::Daily)
            schedule(schedule_selector(DailyMasterPage::dailyMasterTick), .5f);
        return true;
    }
    void dailyMasterTick(float) { daily::DailyManager::get().tryAutoClaim(this); }
    void dailyStatusFinished(GJTimedLevelType type) {
        DailyLevelPage::dailyStatusFinished(type);
        if (type == GJTimedLevelType::Daily) daily::DailyManager::get().dailyStatusFinished(type);
    }
    void dailyStatusFailed(GJTimedLevelType type, GJErrorCode error) {
        DailyLevelPage::dailyStatusFailed(type, error);
        if (type == GJTimedLevelType::Daily) daily::DailyManager::get().dailyStatusFailed(type, error);
    }
    void claimLevelReward(DailyLevelNode* node, GJGameLevel* level, CCPoint position) {
        Ref<GJGameLevel> keepLevel = level;
        auto isDaily = m_type == GJTimedLevelType::Daily && level;
        auto wasClaimed = isDaily && GameStatsManager::sharedState()->hasCompletedDailyLevel(level->m_dailyID.value());
        auto account = GJAccountManager::sharedState()->m_accountID;
        DailyLevelPage::claimLevelReward(node, level, position);
        if (isDaily) daily::DailyManager::get().recordNativeClaim(level, wasClaimed, account);
    }
};
