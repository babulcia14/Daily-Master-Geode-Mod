#include "RewardPolicy.hpp"
#include <iostream>
#include <cstdlib>

using namespace daily;
int main() {
    int count = 0;
    auto expect = [&](RewardFacts facts, RewardState expected, char const* name) {
        ++count;
        if (classify(facts) != expected) {
            std::cerr << "FAIL: " << name << '\n';
            std::exit(1);
        }
    };
    expect({}, RewardState::NoLevel, "no downloaded daily");
    expect({1234, 5678, 0, 7, false}, RewardState::InProgress, "unplayed daily");
    expect({1234, 5678, 99, 7, false}, RewardState::InProgress, "99 percent is not completion");
    expect({1234, 5678, 100, 7, false}, RewardState::Ready, "earned unclaimed reward");
    expect({1234, 5678, 100, 7, true}, RewardState::Claimed, "already claimed cannot be claimed again");
    expect({1234, 5678, 100, 0, false}, RewardState::Unrated, "no unearned reward for unrated level");
    expect({100001, 5678, 100, 10, false}, RewardState::Invalid, "weekly is excluded");
    expect({200001, 5678, 100, 10, false}, RewardState::Invalid, "event is excluded");
    expect({-1, 5678, 100, 7, false}, RewardState::Invalid, "download placeholder is excluded");
    expect({1234, 5678, 101, 7, false}, RewardState::Invalid, "invalid percentage is excluded");
    expect({1234, 5678, 100, 11, false}, RewardState::Invalid, "invalid star count is excluded");
    expect({1234, 0, 100, 7, false}, RewardState::NoLevel, "no real level ID");
    for (int percent = 0; percent < 100; ++percent)
        expect({99999, 5678, percent, 10, false}, RewardState::InProgress, "every incomplete normal percentage");
    std::cout << count << " reward-policy checks passed\n";
}
